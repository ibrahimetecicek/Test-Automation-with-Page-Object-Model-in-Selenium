import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import Pages.HomePage;
import Pages.BooksPage;

public class Searchbox_Test extends BaseTest {

    HomePage homePage ;
    BooksPage booksPage;


    @Test
    @Order(1)
//    @Disabled("Due to BUG-123 disabled")
    public void search_a_product(){
        homePage = new HomePage(driver);
        booksPage = new BooksPage(driver);
        homePage.searchBox().search("Musical Haptics");
        Assertions.assertTrue(booksPage.isOnProductPage() ,
                "Not on products page!");
    }


}


